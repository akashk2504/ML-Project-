# AirWatch Pro — Upgraded Real-Time AQI Prediction

Complete runnable BTech project using Python, Flask, HTML, CSS and JavaScript.

## Added features

- Real-time simulated sensor stream
- Automatic refresh: 2 / 3 / 5 / 10 seconds
- Pause / Resume monitoring
- Multiple Hyderabad monitoring stations
- Interactive Leaflet + OpenStreetMap map with clickable AQI station markers
- Automatic station-marker and station-list refresh during live simulated monitoring
- Live AQI gauge
- Live 20-reading AQI chart
- 24-hour AQI history chart
- Ridge vs Lasso prediction
- Model alpha values
- Lasso feature-selection display
- Health advisory and recommendations
- AQI severity states
- Manual prediction mode
- CSV report download
- Dark/light theme
- Responsive mobile dashboard
- Connection status
- Demo dataset generation
- Missing-value imputation
- Standardization
- 80/20 train-test split
- 5-fold cross-validation
- Ridge/Lasso alpha search

## Run on Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python train_model.py
python app.py
```

Open:

http://127.0.0.1:5000

## Real-time note

The live feed and AQI readings are simulated locally, and the interactive map uses OpenStreetMap tiles. Marker readings refresh from this project’s simulated API; they are not official government sensor measurements. The map requires an internet connection to load map tiles. The API endpoints are structured so a real sensor/API can later replace `generate_live_sensor_data()`.

## Real dataset

Replace `data/air_quality.csv` with a dataset containing:

PM2.5, PM10, NO2, SO2, CO, O3, temperature, humidity, wind_speed, AQI

Then rerun:

```powershell
python train_model.py
```
