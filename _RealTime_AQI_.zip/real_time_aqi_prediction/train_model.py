from pathlib import Path
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import RidgeCV, LassoCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)

FEATURES = [
    "PM2.5", "PM10", "NO2", "SO2", "CO", "O3",
    "temperature", "humidity", "wind_speed"
]
TARGET = "AQI"


def create_demo_dataset(path, rows=2500):
    """Creates a reproducible demo dataset if no real CSV is supplied."""
    rng = np.random.default_rng(42)

    pm25 = rng.uniform(5, 180, rows)
    pm10 = pm25 * rng.uniform(1.25, 2.0, rows) + rng.normal(0, 8, rows)
    no2 = rng.uniform(5, 110, rows)
    so2 = rng.uniform(2, 65, rows)
    co = rng.uniform(0.1, 2.5, rows)
    o3 = rng.uniform(10, 120, rows)
    temperature = rng.uniform(18, 40, rows)
    humidity = rng.uniform(25, 90, rows)
    wind_speed = rng.uniform(0.5, 12, rows)

    aqi = (
        0.62 * pm25 +
        0.16 * pm10 +
        0.34 * no2 +
        0.12 * so2 +
        12.0 * co +
        0.08 * o3 -
        0.08 * wind_speed +
        0.12 * humidity +
        0.15 * temperature +
        rng.normal(0, 8, rows)
    )

    aqi = np.clip(aqi, 5, 500)

    df = pd.DataFrame({
        "PM2.5": pm25,
        "PM10": pm10,
        "NO2": no2,
        "SO2": so2,
        "CO": co,
        "O3": o3,
        "temperature": temperature,
        "humidity": humidity,
        "wind_speed": wind_speed,
        "AQI": aqi
    })

    # Add a small amount of missing data to demonstrate preprocessing.
    for col in FEATURES:
        idx = rng.choice(rows, size=max(1, rows // 100), replace=False)
        df.loc[idx, col] = np.nan

    df.to_csv(path, index=False)


def main():
    DATA_DIR.mkdir(exist_ok=True)
    csv_path = DATA_DIR / "air_quality.csv"

    if not csv_path.exists():
        print("No dataset found. Creating demo air_quality.csv...")
        create_demo_dataset(csv_path)

    df = pd.read_csv(csv_path).drop_duplicates()

    required = FEATURES + [TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing columns: {missing}")

    X = df[FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    preprocessor = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    X_train_p = preprocessor.fit_transform(X_train)
    X_test_p = preprocessor.transform(X_test)

    ridge = RidgeCV(alphas=np.logspace(-3, 3, 100), cv=5)
    lasso = LassoCV(
        alphas=np.logspace(-3, 3, 100),
        cv=5,
        max_iter=10000,
        random_state=42
    )

    ridge.fit(X_train_p, y_train)
    lasso.fit(X_train_p, y_train)

    for name, model in [("Ridge", ridge), ("Lasso", lasso)]:
        pred = model.predict(X_test_p)
        rmse = np.sqrt(mean_squared_error(y_test, pred))
        print(f"\n{name}")
        print(f"MAE : {mean_absolute_error(y_test, pred):.2f}")
        print(f"RMSE: {rmse:.2f}")
        print(f"R2  : {r2_score(y_test, pred):.3f}")
        print(f"Alpha: {model.alpha_:.6f}")

    joblib.dump(preprocessor, MODEL_DIR / "preprocessor.pkl")
    joblib.dump(ridge, MODEL_DIR / "ridge_model.pkl")
    joblib.dump(lasso, MODEL_DIR / "lasso_model.pkl")

    print("\nTraining complete.")
    print("Saved models in:", MODEL_DIR)


if __name__ == "__main__":
    main()
