from flask import Flask, render_template, jsonify, request, Response
import numpy as np
import pandas as pd
import joblib
import time
import csv
import io
from pathlib import Path
from datetime import datetime, timedelta

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models"

app = Flask(__name__)

FEATURES = [
    "PM2.5", "PM10", "NO2", "SO2", "CO", "O3",
    "temperature", "humidity", "wind_speed"
]

STATIONS = [
    {"id": "HYD-01", "name": "Hyderabad Central", "lat": 17.3850, "lng": 78.4867},
    {"id": "HYD-02", "name": "Kukatpally", "lat": 17.4849, "lng": 78.4138},
    {"id": "HYD-03", "name": "Gachibowli", "lat": 17.4401, "lng": 78.3489},
    {"id": "HYD-04", "name": "Secunderabad", "lat": 17.4399, "lng": 78.4983},
    {"id": "HYD-05", "name": "Miyapur", "lat": 17.4969, "lng": 78.3470},
]

preprocessor = joblib.load(MODEL_DIR / "preprocessor.pkl")
ridge_model = joblib.load(MODEL_DIR / "ridge_model.pkl")
lasso_model = joblib.load(MODEL_DIR / "lasso_model.pkl")


def clamp(value, low, high):
    return max(low, min(high, value))


def station_offset(station_id):
    return sum(ord(c) for c in station_id) % 17


def generate_live_sensor_data(station_id="HYD-01"):
    t = time.time()
    off = station_offset(station_id)

    pm25 = 55 + off + 18 * np.sin(t / 18) + np.random.normal(0, 3)
    pm10 = 105 + off * 1.4 + 28 * np.sin(t / 22 + 0.8) + np.random.normal(0, 5)
    no2 = 42 + off * .5 + 12 * np.sin(t / 20 + 1.2) + np.random.normal(0, 2)
    so2 = 18 + off * .2 + 6 * np.sin(t / 25 + 2) + np.random.normal(0, 1)
    co = .8 + off * .01 + .25 * np.sin(t / 24) + np.random.normal(0, .03)
    o3 = 38 + off * .4 + 10 * np.sin(t / 17 + 2.5) + np.random.normal(0, 2)
    temperature = 29 + 2.5 * np.sin(t / 60) + np.random.normal(0, .2)
    humidity = 62 + 8 * np.sin(t / 70 + 1) + np.random.normal(0, .5)
    wind_speed = 4 + 1.2 * np.sin(t / 30) + np.random.normal(0, .15)

    return {
        "PM2.5": round(clamp(pm25, 5, 250), 2),
        "PM10": round(clamp(pm10, 10, 400), 2),
        "NO2": round(clamp(no2, 2, 150), 2),
        "SO2": round(clamp(so2, 1, 100), 2),
        "CO": round(clamp(co, .1, 5), 2),
        "O3": round(clamp(o3, 5, 180), 2),
        "temperature": round(clamp(temperature, 10, 45), 2),
        "humidity": round(clamp(humidity, 20, 95), 2),
        "wind_speed": round(clamp(wind_speed, .2, 15), 2),
    }


def predict(data):
    frame = pd.DataFrame([[data[f] for f in FEATURES]], columns=FEATURES)
    transformed = preprocessor.transform(frame)

    ridge = float(ridge_model.predict(transformed)[0])
    lasso = float(lasso_model.predict(transformed)[0])
    aqi = max(0.0, (ridge + lasso) / 2)

    return {
        "ridge": round(max(0, ridge), 2),
        "lasso": round(max(0, lasso), 2),
        "aqi": round(aqi, 2)
    }


def aqi_status(aqi):
    if aqi <= 50:
        return "Good", "Low health concern", "good"
    if aqi <= 100:
        return "Satisfactory", "Air quality is acceptable", "satisfactory"
    if aqi <= 200:
        return "Moderate", "Sensitive people should take care", "moderate"
    if aqi <= 300:
        return "Poor", "Health alert for sensitive groups", "poor"
    if aqi <= 400:
        return "Very Poor", "Health alert: reduce outdoor activity", "very-poor"
    return "Severe", "Emergency health conditions", "severe"


def make_record(station_id):
    sensor = generate_live_sensor_data(station_id)
    pred = predict(sensor)
    status, message, level = aqi_status(pred["aqi"])
    station = next(s for s in STATIONS if s["id"] == station_id)

    return {
        "timestamp": time.strftime("%H:%M:%S"),
        "iso_time": datetime.now().isoformat(timespec="seconds"),
        "station": station,
        "sensor": sensor,
        "prediction": pred,
        "status": status,
        "message": message,
        "level": level
    }


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/live")
def live_data():
    station_id = request.args.get("station", "HYD-01")
    return jsonify(make_record(station_id))


@app.route("/api/stations")
def stations():
    result = []
    for station in STATIONS:
        record = make_record(station["id"])
        result.append({
            "id": station["id"],
            "name": station["name"],
            "lat": station["lat"],
            "lng": station["lng"],
            "aqi": record["prediction"]["aqi"],
            "status": record["status"],
            "level": record["level"]
        })
    return jsonify(result)


@app.route("/api/model-info")
def model_info():
    ridge_coef = np.asarray(ridge_model.coef_)
    lasso_coef = np.asarray(lasso_model.coef_)

    importance = []
    for feature, rc, lc in zip(FEATURES, ridge_coef, lasso_coef):
        importance.append({
            "feature": feature,
            "ridge": round(float(rc), 4),
            "lasso": round(float(lc), 4),
            "lasso_selected": bool(abs(lc) > 1e-6)
        })

    return jsonify({
        "ridge_alpha": float(ridge_model.alpha_),
        "lasso_alpha": float(lasso_model.alpha_),
        "features": importance
    })


@app.route("/api/predict", methods=["POST"])
def manual_prediction():
    body = request.get_json(silent=True) or {}
    try:
        data = {f: float(body[f]) for f in FEATURES}
    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "All 9 sensor values are required."}), 400

    pred = predict(data)
    status, message, level = aqi_status(pred["aqi"])
    return jsonify({
        "timestamp": time.strftime("%H:%M:%S"),
        "sensor": data,
        "prediction": pred,
        "status": status,
        "message": message,
        "level": level
    })


@app.route("/api/history")
def history():
    station_id = request.args.get("station", "HYD-01")
    points = []
    now = datetime.now()
    # Deterministic-ish historical view for the dashboard.
    rng = np.random.default_rng(station_offset(station_id) + 42)
    base = 125 + station_offset(station_id)
    for i in range(24):
        hour = now - timedelta(hours=23 - i)
        value = max(10, base + 35*np.sin(i/3.4) + rng.normal(0, 9))
        points.append({"time": hour.strftime("%H:%M"), "aqi": round(float(value), 1)})
    return jsonify(points)


@app.route("/api/export")
def export_csv():
    station_id = request.args.get("station", "HYD-01")
    record = make_record(station_id)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Timestamp", "Station", *FEATURES, "Ridge AQI", "Lasso AQI", "Combined AQI", "Status"])
    writer.writerow([
        record["timestamp"], record["station"]["name"],
        *[record["sensor"][f] for f in FEATURES],
        record["prediction"]["ridge"],
        record["prediction"]["lasso"],
        record["prediction"]["aqi"],
        record["status"]
    ])

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=aqi_report.csv"}
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
