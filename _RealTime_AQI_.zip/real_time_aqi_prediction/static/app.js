const $ = id => document.getElementById(id);
const FEATURES = [
  ["PM2.5","pm25"],["PM10","pm10"],["NO2","no2"],["SO2","so2"],["CO","co"],
  ["O3","o3"],["temperature","temperature"],["humidity","humidity"],["wind_speed","wind"]
];

let running = true;
let timer = null;
let refreshSeconds = 3;
let liveValues = [];
let liveLabels = [];
let historyData = [];

let aqiMap = null;
const mapMarkers = {};

function mapColor(level){
  return ({good:"#32d583",satisfactory:"#9bd85a",moderate:"#f6c85f",poor:"#ff9f43", "very-poor":"#ff6b6b", severe:"#c084fc"}[level] || "#58a6ff");
}

function initMap(){
  if(!window.L || aqiMap) return;
  aqiMap = L.map("map", {zoomControl:true, scrollWheelZoom:false}).setView([17.43,78.45], 11);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom:19, attribution:"© OpenStreetMap contributors"
  }).addTo(aqiMap);
  setTimeout(()=>aqiMap.invalidateSize(), 180);
}

function updateMap(data){
  initMap();
  if(!aqiMap) return;
  data.forEach(s=>{
    const color=mapColor(s.level);
    const icon=L.divIcon({className:"aqi-marker-wrap", html:`<div class="aqi-marker" style="--marker-color:${color}">${s.aqi}</div>`, iconSize:[46,46], iconAnchor:[23,23]});
    const popup=`<div class="aqi-popup"><b>${s.name}</b><span>AQI <strong>${s.aqi}</strong> · ${s.level.replace("-"," ")}</span><button onclick="selectStation('${s.id}')">Monitor this station</button></div>`;
    if(mapMarkers[s.id]){mapMarkers[s.id].setLatLng([s.lat,s.lng]).setIcon(icon).setPopupContent(popup);}
    else {mapMarkers[s.id]=L.marker([s.lat,s.lng],{icon}).addTo(aqiMap).bindPopup(popup);}
  });
}

const liveCanvas = $("liveChart");
const historyCanvas = $("historyChart");

function setupCanvas(canvas) {
  const r = canvas.getBoundingClientRect(), dpr = devicePixelRatio || 1;
  canvas.width = r.width*dpr; canvas.height = r.height*dpr;
  const c = canvas.getContext("2d"); c.setTransform(dpr,0,0,dpr,0,0);
  return c;
}

function drawLine(canvas, values, labels, opts={}) {
  const ctx = setupCanvas(canvas), w=canvas.clientWidth, h=canvas.clientHeight;
  ctx.clearRect(0,0,w,h);
  ctx.font = "10px system-ui";
  ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--line") || "rgba(148,163,184,.12)";
  for(let i=0;i<5;i++){let y=15+(h-35)*i/4;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  if(values.length<2)return;
  const max=Math.max(opts.max||100,...values)*1.12, min=0;
  const pts=values.map((v,i)=>[i*(w/Math.max(1,values.length-1)),h-28-(v-min)/(max-min)*(h-48)]);
  ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));
  ctx.strokeStyle=opts.color||"#58a6ff";ctx.lineWidth=3;ctx.stroke();
  ctx.lineTo(pts.at(-1)[0],h);ctx.lineTo(0,h);ctx.closePath();
  ctx.fillStyle=opts.fill||"rgba(88,166,255,.08)";ctx.fill();
  ctx.fillStyle=getComputedStyle(document.documentElement).getPropertyValue("--muted")||"#91a2b8";
  if(labels.length){ctx.fillText(labels[0],2,h-6);ctx.fillText(labels.at(-1),w-45,h-6);}
}

function drawCharts(){drawLine(liveCanvas,liveValues,liveLabels,{max:300});drawLine(historyCanvas,historyData.map(x=>x.aqi),historyData.map(x=>x.time),{max:300});}

function statusClass(level){return level||"good";}

function updateGauge(aqi){
  const pct=Math.min(100,Math.max(0,aqi/500*100));
  $("gaugeFill").style.width=pct+"%";
}

function updateRecommendations(level){
  const actions={
    good:["Normal outdoor activities are appropriate.","Continue monitoring local conditions."],
    satisfactory:["Most people can continue normal activities.","Sensitive people may monitor symptoms."],
    moderate:["Sensitive groups should reduce prolonged outdoor activity.","Keep windows closed during pollution peaks."],
    poor:["Reduce prolonged outdoor activity.","Use a mask outdoors if needed and monitor symptoms."],
    "very-poor":["Avoid unnecessary outdoor activity.","Sensitive groups should remain indoors where possible."],
    severe:["Avoid outdoor exposure.","Follow local health authority guidance and seek help for severe symptoms."]
  };
  $("recommendations").innerHTML=(actions[level]||actions.moderate).map(x=>`<li>${x}</li>`).join("");
}

async function loadStations(){
  initMap();
  const data=await fetch("/api/stations").then(r=>r.json());
  $("stationSelect").innerHTML=data.map(s=>`<option value="${s.id}">${s.name}</option>`).join("");
  renderStations(data);
}

function renderStations(data){
  updateMap(data);
  $("stationList").innerHTML=data.map(s=>`<button class="station-row" onclick="selectStation('${s.id}')"><span><i class="${s.level}"></i>${s.name}</span><b>${s.aqi}</b></button>`).join("");
}

window.selectStation=id=>{$("stationSelect").value=id;fetchLive();loadHistory();};

async function fetchLive(){
  try{
    const station=$("stationSelect").value||"HYD-01";
    const d=await fetch(`/api/live?station=${station}`,{cache:"no-store"}).then(r=>r.json());
    const s=d.sensor,p=d.prediction;
    $("aqi").textContent=p.aqi;$("ridge").textContent=p.ridge;$("lasso").textContent=p.lasso;
    $("status").textContent=d.status;$("message").textContent=d.message;
    $("updated").textContent=d.timestamp;$("stationName").textContent=d.station.name;
    FEATURES.forEach(([key,id])=>$(id).textContent=s[key]);
    $("connection").textContent="● Connected";$("connection").className="connected";
    liveValues.push(p.aqi);liveLabels.push(d.timestamp);
    if(liveValues.length>20){liveValues.shift();liveLabels.shift();}
    updateGauge(p.aqi);applyLevel(d.level);updateRecommendations(d.level);
    // Refresh the station network so map markers and station cards stay live.
    try {
      const stations = await fetch("/api/stations", {cache:"no-store"}).then(r=>r.json());
      const current = stations.find(x=>x.id===station);
      if(current){ current.aqi=p.aqi; current.status=d.status; current.level=d.level; }
      renderStations(stations);
    } catch(mapError) { console.debug("Station map refresh skipped", mapError); }
    drawCharts();
  }catch(e){
    $("connection").textContent="● Offline";$("connection").className="offline";
  }
}

function applyLevel(level){
  document.body.dataset.level=level;
  $("alertTitle").textContent=$("status").textContent;
  $("alertHeading").textContent=$("status").textContent;
  $("alertText").textContent=$("message").textContent;
  $("alertBadge").textContent=level.toUpperCase();
}

async function loadHistory(){
  const station=$("stationSelect").value||"HYD-01";
  historyData=await fetch(`/api/history?station=${station}`).then(r=>r.json());
  drawCharts();
}

async function loadModelInfo(){
  const d=await fetch("/api/model-info").then(r=>r.json());
  $("ridgeAlpha").textContent=d.ridge_alpha.toFixed(4);
  $("lassoAlpha").textContent=d.lasso_alpha.toFixed(4);
  $("featureBars").innerHTML=d.features.map(x=>{
    const v=Math.abs(x.lasso), width=Math.min(100,v*8);
    return `<div class="feature"><span>${x.feature}</span><div><i style="width:${width}%"></i></div><b>${x.lasso_selected?"selected":"zero"}</b></div>`;
  }).join("");
  $("bestModel").textContent="Ridge & Lasso comparison ready";
}

function setupManual(){
  $("manualInputs").innerHTML=FEATURES.map(([key,id])=>`
    <label>${key}<input name="${key}" type="number" step="any" value="${key==="PM2.5"?60:key==="PM10"?110:key==="NO2"?45:key==="SO2"?18:key==="CO"?.9:key==="O3"?40:key==="temperature"?29:key==="humidity"?62:4}" required></label>`).join("");
  $("manualForm").onsubmit=async e=>{
    e.preventDefault();
    const body={};new FormData(e.target).forEach((v,k)=>body[k]=Number(v));
    const r=await fetch("/api/predict",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const d=await r.json();
    if(d.error)return;
    $("manualResult").classList.remove("hidden");
    $("manualResult").innerHTML=`<b>Predicted AQI: ${d.prediction.aqi}</b><span>${d.status}</span><small>Ridge ${d.prediction.ridge} • Lasso ${d.prediction.lasso}</small>`;
  };
}

function startTimer(){
  clearInterval(timer);
  if(running)timer=setInterval(fetchLive,refreshSeconds*1000);
}

$("refreshSelect").onchange=e=>{refreshSeconds=Number(e.target.value);startTimer();};
$("monitorBtn").onclick=()=>{running=!running;$("monitorBtn").textContent=running?"⏸ Pause":"▶ Resume";startTimer();};
$("stationSelect").onchange=()=>{fetchLive();loadHistory();};

$("exportBtn").onclick=()=>{
  const station=$("stationSelect").value||"HYD-01";
  window.location.href=`/api/export?station=${station}`;
};

$("themeBtn").onclick=()=>{
  document.body.classList.toggle("light");
  $("themeBtn").textContent=document.body.classList.contains("light")?"☀":"☾";
};

window.addEventListener("resize",drawCharts);

(async function init(){
  setupManual();
  await loadStations();
  await loadModelInfo();
  await loadHistory();
  await fetchLive();
  startTimer();
})();


// Interactive dashboard action center
function setAction(text){ const el=$("lastAction"); if(el){el.textContent=text; el.animate([{opacity:.35},{opacity:1}],{duration:250});} }
function openModal(title, content, eyebrow="AIRWATCH PRO"){
  $("modalTitle").textContent=title; $("modalEyebrow").textContent=eyebrow; $("modalContent").innerHTML=content; $("modalBackdrop").classList.add("open");
}
function closeModal(){ $("modalBackdrop").classList.remove("open"); }
$("modalClose").onclick=closeModal;
$("modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")closeModal();};
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});

$("startBtn").onclick=()=>{running=true;$("monitorBtn").textContent="⏸ Pause";startTimer();setAction("Monitoring started");};
$("pauseBtn").onclick=()=>{running=false;clearInterval(timer);$("monitorBtn").textContent="▶ Resume";setAction("Monitoring paused");};
$("refreshBtn").onclick=async()=>{await fetchLive();setAction("Data refreshed now");};
$("stationsBtn").onclick=()=>{openModal("Monitoring Stations", Array.from(document.querySelectorAll(".station-row")).map(x=>`<div class="modal-stat"><span>STATION</span><b>${x.querySelector("span").textContent.trim()}</b><small>AQI ${x.querySelector("b").textContent}</small></div>`).join("<br>")||"No stations loaded.","STATION NETWORK");setAction("Station list opened");};
$("historyBtn").onclick=()=>{openModal("AQI History",`<div class="modal-note">The main dashboard contains the full 24-hour AQI history chart for the selected station. Current stored readings: <b>${historyData.length}</b>.</div><br><div class="modal-content-grid">${historyData.slice(-6).reverse().map(x=>`<div class="modal-stat"><span>${x.time}</span><b>AQI ${x.aqi}</b></div>`).join("")}</div>` ,"TREND ANALYSIS");setAction("History opened");};
$("pollutantsBtn").onclick=()=>{openModal("Current Pollutants",`<div class="modal-content-grid">${FEATURES.slice(0,6).map(([k,id])=>`<div class="modal-stat"><span>${k}</span><b>${$(id).textContent}</b></div>`).join("")}</div><br><div class="modal-note">These values are updated automatically from the simulated live sensor feed.</div>` ,"LIVE TELEMETRY");setAction("Pollutants opened");};
$("modelBtn").onclick=()=>{openModal("Ridge vs Lasso",`<div class="modal-content-grid"><div class="modal-stat"><span>RIDGE ALPHA</span><b>${$("ridgeAlpha").textContent}</b></div><div class="modal-stat"><span>LASSO ALPHA</span><b>${$("lassoAlpha").textContent}</b></div></div><br><div class="modal-note"><b>${$("bestModel").textContent}</b><br>Ridge stabilizes coefficients while Lasso can set weak feature coefficients to zero. Use the feature-selection panel for detailed coefficients.</div>` ,"MODEL ANALYTICS");setAction("Model info opened");};
$("manualBtn").onclick=()=>{document.querySelector(".manual").scrollIntoView({behavior:"smooth"});$("manualInputs input")?.focus();setAction("Manual prediction selected");};
$("alertBtn").onclick=()=>{openModal("Current Health Alert",`<div class="modal-note"><b>${$("alertHeading").textContent}</b><br>${$("alertText").textContent}</div><h3>Recommended actions</h3><ul class="modal-list">${$("recommendations").innerHTML}</ul>` ,"HEALTH ADVISORY");setAction("Health alert opened");};
$("reportBtn").onclick=()=>{$("exportBtn").click();setAction("CSV report requested");};
let notificationsOn=true;
$("notifyBtn").onclick=()=>{notificationsOn=!notificationsOn;$("notifyBtn").textContent=notificationsOn?"🔔 Alerts On":"🔕 Alerts Off";setAction(notificationsOn?"Alerts enabled":"Alerts disabled");};
$("resetBtn").onclick=()=>{liveValues=[];liveLabels=[];drawCharts();$("stationSelect").selectedIndex=0;fetchLive();loadHistory();setAction("Dashboard reset");};
