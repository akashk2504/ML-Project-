@echo off
echo ========================================
echo     AIRWATCH PRO - AQI PREDICTION
echo ========================================
if not exist .venv (
    python -m venv .venv
)
call .venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
python app.py
pause
